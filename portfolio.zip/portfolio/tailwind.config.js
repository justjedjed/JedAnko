/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{html,js,svelte,ts}'],
  theme: {
    extend: {},
  },
  plugins: [require('daisyui')],
  daisyui: {
    themes: ['night', 'light', 'cupcake', 'cyberpunk', 'forest'],
    // Change default theme here — 'night' is dark, 'light' is light
    // You can also let users switch themes with a theme controller button
  },
};
