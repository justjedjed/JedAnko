<script>
  import Sidebar from '$lib/components/Sidebar.svelte';
  import Hero from '$lib/components/Hero.svelte';
  import TechStack from '$lib/components/TechStack.svelte';
  import Projects from '$lib/components/Projects.svelte';
  import HostedSites from '$lib/components/HostedSites.svelte';
  import Contact from '$lib/components/Contact.svelte';

  let activeSection = 'about';

  function scrollTo(id) {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
    activeSection = id;
  }
</script>

<div class="flex min-h-screen bg-base-100">
  <Sidebar {activeSection} {scrollTo} />

  <!-- Main content: offset for sidebar on large screens -->
  <main class="flex-1 lg:ml-64 w-full">
    <section id="about"><Hero /></section>
    <section id="stack"><TechStack /></section>
    <section id="projects"><Projects /></section>
    <section id="hosted"><HostedSites /></section>
    <section id="contact"><Contact /></section>
  </main>
</div>
