<script>
  // Replace with your own projects
  const projects = [
    {
      title: 'E-Commerce Platform',
      description: 'A full-stack e-commerce app with cart, payments, and admin dashboard. Built with SvelteKit and Supabase.',
      tags: ['SvelteKit', 'Supabase', 'TailwindCSS', 'Stripe'],
      github: 'https://github.com/yourusername/project1',
      demo: 'https://project1.vercel.app',
      status: 'Completed',
      statusColor: 'badge-success',
    },
    {
      title: 'Task Management App',
      description: 'A Kanban-style project management tool with real-time collaboration using Firebase.',
      tags: ['Vue.js', 'Firebase', 'DaisyUI'],
      github: 'https://github.com/yourusername/project2',
      demo: 'https://project2.vercel.app',
      status: 'In Progress',
      statusColor: 'badge-warning',
    },
    {
      title: 'REST API Boilerplate',
      description: 'A production-ready Express + PostgreSQL REST API template with JWT auth, rate limiting, and Docker support.',
      tags: ['Node.js', 'Express', 'PostgreSQL', 'Docker'],
      github: 'https://github.com/yourusername/project3',
      demo: null,
      status: 'Open Source',
      statusColor: 'badge-info',
    },
    {
      title: 'Portfolio Website',
      description: 'This very portfolio — built with SvelteKit and DaisyUI, fully responsive and accessible.',
      tags: ['SvelteKit', 'DaisyUI', 'TailwindCSS'],
      github: 'https://github.com/yourusername/portfolio',
      demo: 'https://yourportfolio.vercel.app',
      status: 'Completed',
      statusColor: 'badge-success',
    },
  ];
</script>

<div class="min-h-screen flex items-center px-6 py-20">
  <div class="max-w-3xl w-full mx-auto">

    <!-- Header -->
    <div class="mb-12">
      <p class="text-xs text-primary font-bold uppercase tracking-widest mb-1">What I've built</p>
      <h2 class="text-4xl font-black text-base-content">Projects</h2>
      <p class="text-base-content/50 mt-2 text-sm max-w-md">
        Personal and freelance projects — from side experiments to production-ready applications.
      </p>
    </div>

    <!-- Projects grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
      {#each projects as project}
        <div class="card bg-base-100 border border-base-300 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-200 group">
          <div class="card-body p-5 flex flex-col gap-3">
            <!-- Title + Status -->
            <div class="flex items-start justify-between gap-2">
              <h3 class="font-bold text-base-content text-base leading-snug group-hover:text-primary transition-colors">
                {project.title}
              </h3>
              <span class="badge {project.statusColor} badge-sm shrink-0">{project.status}</span>
            </div>

            <!-- Description -->
            <p class="text-sm text-base-content/60 leading-relaxed flex-1">{project.description}</p>

            <!-- Tags -->
            <div class="flex flex-wrap gap-1.5 mt-1">
              {#each project.tags as tag}
                <span class="badge badge-outline badge-xs text-base-content/50">{tag}</span>
              {/each}
            </div>

            <!-- Links -->
            <div class="flex gap-2 mt-2">
              {#if project.github}
                <a href={project.github} target="_blank" rel="noopener noreferrer" class="btn btn-ghost btn-xs gap-1">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z"/>
                  </svg>
                  Code
                </a>
              {/if}
              {#if project.demo}
                <a href={project.demo} target="_blank" rel="noopener noreferrer" class="btn btn-ghost btn-xs gap-1 text-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                  Live Demo
                </a>
              {/if}
            </div>
          </div>
        </div>
      {/each}
    </div>

  </div>
</div>
