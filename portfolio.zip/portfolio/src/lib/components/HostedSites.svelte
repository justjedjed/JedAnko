<script>
  // Replace with real hosted websites you assisted/built
  const sites = [
    {
      name: 'Client Business Website',
      url: 'https://example-client.com',
      description: 'Company profile and services site for a local business in Davao City.',
      role: 'Lead Developer',
      tech: ['SvelteKit', 'TailwindCSS'],
      thumbnail: 'https://placehold.co/600x360/1e293b/94a3b8?text=Client+Site',
    },
    {
      name: 'Restaurant Landing Page',
      url: 'https://example-restaurant.com',
      description: 'Modern landing page with online menu and reservation system.',
      role: 'Frontend Developer',
      tech: ['HTML', 'CSS', 'JavaScript'],
      thumbnail: 'https://placehold.co/600x360/1e293b/94a3b8?text=Restaurant+Site',
    },
    {
      name: 'NGO Advocacy Site',
      url: 'https://example-ngo.org',
      description: 'Advocacy and donation platform for a local non-profit organization.',
      role: 'Full-Stack Developer',
      tech: ['Laravel', 'Vue.js', 'MySQL'],
      thumbnail: 'https://placehold.co/600x360/1e293b/94a3b8?text=NGO+Site',
    },
    {
      name: 'Online Ordering System',
      url: 'https://example-order.com',
      description: 'Custom ordering platform with SMS notifications and delivery tracking.',
      role: 'Backend Developer',
      tech: ['Node.js', 'Express', 'Supabase'],
      thumbnail: 'https://placehold.co/600x360/1e293b/94a3b8?text=Order+System',
    },
    {
      name: 'School Portal',
      url: 'https://example-school.edu.ph',
      description: 'Student portal with enrollment, grades, and announcement management.',
      role: 'Full-Stack Developer',
      tech: ['Laravel', 'Livewire', 'MySQL'],
      thumbnail: 'https://placehold.co/600x360/1e293b/94a3b8?text=School+Portal',
    },
  ];
</script>

<div class="min-h-screen flex items-center px-6 py-20 bg-base-200">
  <div class="max-w-3xl w-full mx-auto">

    <!-- Header -->
    <div class="mb-12">
      <p class="text-xs text-primary font-bold uppercase tracking-widest mb-1">Live on the web</p>
      <h2 class="text-4xl font-black text-base-content">Hosted Websites</h2>
      <p class="text-base-content/50 mt-2 text-sm max-w-md">
        Real-world websites I helped design, develop, and deploy for clients and organizations.
      </p>
    </div>

    <!-- Sites list -->
    <div class="flex flex-col gap-4">
      {#each sites as site}
        <div class="card card-side bg-base-100 border border-base-300 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 overflow-hidden">
          <!-- Thumbnail -->
          <figure class="w-36 shrink-0 hidden sm:block">
            <img src={site.thumbnail} alt={site.name} class="h-full w-full object-cover" />
          </figure>

          <div class="card-body p-4 gap-2">
            <div class="flex items-start justify-between gap-2 flex-wrap">
              <h3 class="font-bold text-base text-base-content">{site.name}</h3>
              <span class="badge badge-primary badge-outline badge-sm shrink-0">{site.role}</span>
            </div>
            <p class="text-sm text-base-content/60 leading-relaxed">{site.description}</p>
            <div class="flex flex-wrap gap-1.5">
              {#each site.tech as t}
                <span class="badge badge-ghost badge-xs">{t}</span>
              {/each}
            </div>
            <div class="mt-1">
              <a href={site.url} target="_blank" rel="noopener noreferrer" class="btn btn-xs btn-primary gap-1">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                </svg>
                Visit Site
              </a>
            </div>
          </div>
        </div>
      {/each}
    </div>

  </div>
</div>
