<script>
  export let activeSection = 'about';
  export let scrollTo = () => {};

  const navItems = [
    { id: 'about',    label: 'About',         icon: '👤' },
    { id: 'stack',    label: 'Tech Stack',    icon: '⚙️' },
    { id: 'projects', label: 'Projects',      icon: '🗂️' },
    { id: 'hosted',   label: 'Hosted Sites',  icon: '🌐' },
    { id: 'contact',  label: 'Contact',       icon: '✉️' },
  ];

  let drawerOpen = false;
</script>

<!-- Mobile top bar -->
<div class="lg:hidden fixed top-0 left-0 right-0 z-50 bg-base-200 border-b border-base-300 flex items-center px-4 h-14">
  <button class="btn btn-ghost btn-sm" on:click={() => drawerOpen = !drawerOpen}>
    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
    </svg>
  </button>
  <span class="ml-3 font-bold text-primary tracking-widest text-sm uppercase">Portfolio</span>
</div>

<!-- Mobile drawer overlay -->
{#if drawerOpen}
  <div
    class="lg:hidden fixed inset-0 z-40 bg-black/50"
    on:click={() => drawerOpen = false}
    role="button"
    tabindex="0"
    on:keydown={(e) => e.key === 'Escape' && (drawerOpen = false)}
  ></div>
{/if}

<!-- Sidebar -->
<aside
  class="
    fixed top-0 left-0 h-full z-50 w-64
    bg-base-200 border-r border-base-300
    flex flex-col py-8 px-5
    transition-transform duration-300
    {drawerOpen ? 'translate-x-0' : '-translate-x-full'}
    lg:translate-x-0
  "
>
  <!-- Avatar + Name -->
  <div class="flex flex-col items-center gap-3 mb-10">
    <div class="avatar">
      <div class="w-20 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
        <!-- Replace src with your actual photo -->
        <img src="https://api.dicebear.com/9.x/notionists/svg?seed=portfolio" alt="Avatar" />
      </div>
    </div>
    <div class="text-center">
      <p class="font-bold text-base-content text-lg leading-tight">Your Name</p>
      <p class="text-xs text-base-content/50 tracking-widest uppercase mt-0.5">Full-Stack Dev</p>
    </div>
  </div>

  <!-- Nav -->
  <nav class="flex flex-col gap-1 flex-1">
    {#each navItems as item}
      <button
        class="
          btn btn-ghost justify-start gap-3 text-sm font-medium
          {activeSection === item.id ? 'btn-active text-primary' : 'text-base-content/70'}
        "
        on:click={() => { scrollTo(item.id); drawerOpen = false; }}
      >
        <span class="text-base">{item.icon}</span>
        {item.label}
      </button>
    {/each}
  </nav>

  <!-- Footer -->
  <div class="mt-auto pt-6 border-t border-base-300 text-center">
    <p class="text-xs text-base-content/40">© 2025 Your Name</p>
  </div>
</aside>
