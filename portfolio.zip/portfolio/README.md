# My Portfolio — SvelteKit + DaisyUI

A personal developer portfolio with a fixed sidebar and 5 sections.

## Sections
1. **About** — Personal info, bio, stats, social links
2. **Tech Stack** — Tools and technologies with skill levels
3. **Projects** — Personal & freelance projects
4. **Hosted Sites** — Live websites you helped build
5. **Contact** — Email, Facebook, GitHub, LinkedIn

## Quick Start

```bash
npm install
npm run dev
```

## Customization Checklist

### `src/lib/components/Hero.svelte`
- [ ] `name` — your full name
- [ ] `role` — your job title
- [ ] `location` — your city/country
- [ ] `bio` — your personal bio
- [ ] `resumeLink` — link to your resume PDF
- [ ] GitHub and LinkedIn URLs in the CTA buttons
- [ ] Stats numbers (years exp, projects, live sites)

### `src/lib/components/Sidebar.svelte`
- [ ] Replace avatar `src` with your photo URL

### `src/lib/components/TechStack.svelte`
- [ ] Edit `categories` array — add/remove techs and set levels

### `src/lib/components/Projects.svelte`
- [ ] Edit `projects` array — title, description, tags, links, status

### `src/lib/components/HostedSites.svelte`
- [ ] Edit `sites` array — name, URL, description, role, tech, thumbnail

### `src/lib/components/Contact.svelte`
- [ ] `email` — your email address
- [ ] `facebookProfile` — Facebook profile URL
- [ ] `facebookName` — your name as shown on Facebook
- [ ] `githubProfile` — GitHub profile URL
- [ ] `linkedinProfile` — LinkedIn profile URL

## Change Theme
In `src/app.html`, change `data-theme="night"` to any DaisyUI theme:
- `light`, `dark`, `night`, `forest`, `cyberpunk`, `cupcake`, etc.

Full theme list: https://daisyui.com/docs/themes/

## Deploy to Vercel
```bash
npm i -g vercel
vercel
```
